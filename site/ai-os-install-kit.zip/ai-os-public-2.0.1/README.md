# ai-os-public

Product version: **v2.0.1** ([release notes](docs/releases/v2.0.1.md), [changelog](CHANGELOG.md)).
The canonical product version is stored in `VERSION`; runtime contract and storage identifiers are separate.

A starter library for building an AI Operating System on top of [Claude Code](https://docs.claude.com/claude-code): protocol skills, agent personas, and a `librarian` subagent. Methodology and governance scaffolding to customize, not a turnkey product. See [`CLAUDE.md`](CLAUDE.md) for the full audience contract and what is *not* shared.

## Interactive guide

[Working with AI Agents](https://simonepaciphd.github.io/ai-os-public/) — a practical guide to the principles, components, and lifecycle of an AI OS task.

## Planning a research project with an agent

A student edition of the planning workflow is published with the POLISCI 290
capstone course: the agent helps you specify what the finished project must
contain, list the resources you have, and write a step-by-step plan with checks.
You make every research choice.
[Browse the folder](https://github.com/simonepaciphd/polisci290-capstone/tree/main/research-planning)
or [download the zip](https://simonepaciphd.github.io/polisci290-capstone/research-planning.zip).

The full planning family ships in `skills/`: [`planning-protocol.md`](skills/planning-protocol.md)
coordinates eight stage protocols (`planning-*-protocol.md`) from output
specification through resource map, task map, adversarial review, adjudication,
baseline lock and spec reconciliation. The plan-viewer tool in
[`skills/_assets/plan-viewer/`](skills/_assets/plan-viewer/README.md) lints a
project's `planning/` folder and builds a self-contained plan page (Python 3,
standard library only); the governance file templates are in
`skills/_assets/planning-templates/`.

## Native bookkeeping installation

Already have a project folder? After installing native bookkeeping, say
**“Register this existing project: [path].”** The
[registration workflow](skills/project-registration.md) previews and completes
registration without changing the folder structure.

For session registration, hooks, claims, snapshots and closeout, use the
[technical installer guide](docs/setup-guides/native-bookkeeping-install.md).
Requires Python 3.11+ and Git; installs locally for selected projects.

## Quick start

Pick the tool you use. Each guide is a step-by-step walkthrough that does not assume terminal experience.

- **Claude Code (terminal).** [Setup guide →](docs/setup-guides/claude-code-setup.md)
- **Claude desktop app.** *Coming soon.* [Placeholder →](docs/setup-guides/claude-desktop-setup.md)
- **Codex app.** *Coming soon.* [Placeholder →](docs/setup-guides/codex-setup.md)

## What's in the repo

- `skills/` — protocol skills (`*.md`), the building blocks the personas reach for.
- `skills/_assets/` — supporting files for individual skills (currently: the plan viewer and the planning templates).
- `personas/` — five session-level agent personas (table below).
- `agents/` — installable subagents (currently: `librarian`).
- `CLAUDE.md` — tier-level orientation, audience contract, placeholder vocabulary.

## Personas

| Persona          | Purpose                                                                      | Notes                                                              |
| ---------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| `chief-of-staff` | Portfolio oversight, project monitoring, routing.                            | Refuses substantive work.                                          |
| `researcher`     | Senior-scholar collaborator across theory, design, empirics, interpretation. | Refuses prose; refuses substantive decisions on the user's behalf. |
| `writer`         | Co-writer for prose deliverables.                                            | Ships as a stub: voice-bearing skills are user-defined.            |
| `engineer`       | Technical infrastructure and the agentic OS itself.                          | Refuses research substance and prose.                              |
| `teacher`        | Course design, assignment design, lecture prep, pedagogical reflection.      | Default skills are user-defined and not shipped.                   |

## License

MIT — see [`LICENSE`](LICENSE).

## Citation

If you use these protocols in published work:

> Paci, Simone (2026). *AI Operating System — public protocols.* GitHub repository. https://github.com/simonepaciphd/ai-os-public

The governing principles trace back to: Paci, Simone (April 2026 working draft), *With Great Powers*, https://simonepaciphd.github.io/with-great-powers/.
